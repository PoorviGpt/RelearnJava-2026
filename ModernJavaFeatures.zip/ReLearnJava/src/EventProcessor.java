import java.math.BigDecimal;
import java.time.Instant;

public final class EventProcessor {

    public ProcessingResult process(PaymentEvent event) {
        return switch (event) {
            case null -> new ProcessingResult(
                    ProcessingState.REJECTED,
                    BusinessOutcome.NONE,
                    "Event cannot be null"
            );

            case PaymentInitiated(String paymentId, BigDecimal amount, String currency, Instant initiatedAt) ->
                    new ProcessingResult(
                            ProcessingState.PROCESSED,
                            BusinessOutcome.PAYMENT_INITIATED,
                            "Payment %s initiated for %s %s at %s"
                                    .formatted(paymentId, amount, currency, initiatedAt)
                    );

            case PaymentCompleted(String paymentId, BigDecimal amount, String transactionId, Instant completedAt) ->
                    new ProcessingResult(
                            ProcessingState.PROCESSED,
                            BusinessOutcome.PAYMENT_COMPLETED,
                            "Payment %s completed for %s with transaction %s at %s"
                                    .formatted(paymentId, amount, transactionId, completedAt)
                    );

            case PaymentFailed(String paymentId, String reason, Instant failedAt) ->
                    new ProcessingResult(
                            ProcessingState.PROCESSED,
                            BusinessOutcome.PAYMENT_FAILED,
                            "Payment %s failed because '%s' at %s"
                                    .formatted(paymentId, reason, failedAt)
                    );

            case RefundIssued(String paymentId, String refundId, BigDecimal amount, String reason, Instant refundedAt) ->
                    new ProcessingResult(
                            ProcessingState.PROCESSED,
                            BusinessOutcome.REFUND_ISSUED,
                            "Refund %s issued for payment %s, amount %s, reason '%s', at %s"
                                    .formatted(refundId, paymentId, amount, reason, refundedAt)
                    );

            case ChargebackRaised(String paymentId, String chargebackId, BigDecimal amount, String reason, Instant raisedAt) ->
                    new ProcessingResult(
                            ProcessingState.REVIEW_REQUIRED,
                            BusinessOutcome.CHARGEBACK_FLAGGED,
                            "Chargeback %s raised for payment %s, amount %s, reason '%s', flagged for review at %s"
                                    .formatted(chargebackId, paymentId, amount, reason, raisedAt)
                    );
        };
    }
}