import java.math.BigDecimal;
import java.util.Objects;

public final class Validation {
    private Validation() {
    }

    static void requireNotBlank(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
    }

    static void requirePositive(BigDecimal value, String fieldName) {
        if (value == null || value.signum() <= 0) {
            throw new IllegalArgumentException(fieldName + " must be positive");
        }
    }

    static <T> void requireNonNull(T value, String fieldName) {
        Objects.requireNonNull(value, fieldName + " must not be null");
    }
}
