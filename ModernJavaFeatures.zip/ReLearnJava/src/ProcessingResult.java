public record ProcessingResult(
        ProcessingState state,
        BusinessOutcome outcome,
        String message
) {
    public ProcessingResult {
        Validation.requireNonNull(state, "state");
        Validation.requireNonNull(outcome, "outcome");
        Validation.requireNotBlank(message, "message");
    }
}