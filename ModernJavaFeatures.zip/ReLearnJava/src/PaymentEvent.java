import java.math.BigDecimal;
import java.time.Instant;

sealed interface PaymentEvent
        permits PaymentInitiated, PaymentCompleted, PaymentFailed, RefundIssued, ChargebackRaised {
}

record PaymentInitiated(
        String paymentId,
        BigDecimal amount,
        String currency,
        Instant initiatedAt
) implements PaymentEvent {
    public PaymentInitiated {
        Validation.requireNotBlank(paymentId, "paymentId");
        Validation.requirePositive(amount, "amount");
        Validation.requireNotBlank(currency, "currency");
        Validation.requireNonNull(initiatedAt, "initiatedAt");
    }
}

record PaymentCompleted(
        String paymentId,
        BigDecimal amount,
        String transactionId,
        Instant completedAt
) implements PaymentEvent {
    public PaymentCompleted {
        Validation.requireNotBlank(paymentId, "paymentId");
        Validation.requirePositive(amount, "amount");
        Validation.requireNotBlank(transactionId, "transactionId");
        Validation.requireNonNull(completedAt, "completedAt");
    }
}

record PaymentFailed(
        String paymentId,
        String reason,
        Instant failedAt
) implements PaymentEvent {
    public PaymentFailed {
        Validation.requireNotBlank(paymentId, "paymentId");
        Validation.requireNotBlank(reason, "reason");
        Validation.requireNonNull(failedAt, "failedAt");
    }
}

record RefundIssued(
        String paymentId,
        String refundId,
        BigDecimal amount,
        String reason,
        Instant refundedAt
) implements PaymentEvent {
    public RefundIssued {
        Validation.requireNotBlank(paymentId, "paymentId");
        Validation.requireNotBlank(refundId, "refundId");
        Validation.requirePositive(amount, "amount");
        Validation.requireNotBlank(reason, "reason");
        Validation.requireNonNull(refundedAt, "refundedAt");
    }
}

record ChargebackRaised(
        String paymentId,
        String chargebackId,
        BigDecimal amount,
        String reason,
        Instant raisedAt
) implements PaymentEvent {
    public ChargebackRaised {
        Validation.requireNotBlank(paymentId, "paymentId");
        Validation.requireNotBlank(chargebackId, "chargebackId");
        Validation.requirePositive(amount, "amount");
        Validation.requireNotBlank(reason, "reason");
        Validation.requireNonNull(raisedAt, "raisedAt");
    }
}