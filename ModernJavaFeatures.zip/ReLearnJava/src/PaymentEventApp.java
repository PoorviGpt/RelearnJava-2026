import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

public class PaymentEventApp {

    public static void main(String[] args) {
        EventProcessor processor = new EventProcessor();

        List<PaymentEvent> events = List.of(
                new PaymentInitiated("pay-1001", BigDecimal.valueOf(1.0), "USD",
                        Instant.parse("2026-05-31T10:15:30Z")),

                new PaymentCompleted("pay-1001", new BigDecimal("125.00"), "txn-9001",
                        Instant.parse("2026-05-31T10:16:05Z")),

                new PaymentFailed("pay-1002", "Insufficient funds",
                        Instant.parse("2026-05-31T10:17:10Z")),

                new RefundIssued("pay-1001", "ref-7001", new BigDecimal("25.00"),
                        "Partial refund", Instant.parse("2026-05-31T10:18:20Z")),

                new ChargebackRaised("pay-1003", "cb-3001", new BigDecimal("80.00"),
                        "Cardholder dispute", Instant.parse("2026-05-31T10:19:45Z"))
        );

        events.stream()
                .map(processor::process)
                .forEach(result -> System.out.printf(
                        "state=%s | outcome=%s | message=%s%n",
                        result.state(), result.outcome(), result.message()
                ));
    }
}
