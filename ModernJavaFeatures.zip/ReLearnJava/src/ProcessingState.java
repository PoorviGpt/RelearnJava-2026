public enum ProcessingState {
    PROCESSED,
    REVIEW_REQUIRED,
    REJECTED
}