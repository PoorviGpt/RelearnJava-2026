package com.relearn.project.employeeappdb;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

    private EmployeeRepository employeeRepository;

    @GetMapping("/employee/{name}")
    public Employee saveEmployee(@PathVariable String name) {
        return employeeRepository.save(new Employee(name));
    }

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }
}
