package com.relearn.project.employeeappdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAppDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
